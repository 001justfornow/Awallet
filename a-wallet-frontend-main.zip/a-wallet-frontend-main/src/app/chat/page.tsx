import {ReactNode} from "react";
import {ArrowDownIcon, ArrowPathIcon, ArrowUpIcon, TonIcon, USDTIcon} from "@/components/icons";
import Image from "next/image";
import Link from "next/link";





export default function Home() {
    return (
        <main className="w-full min-h-screen p-4">
            <div className="flex flex-col w-full bg-white rounded-[10px] py-2.5 px-4">
                fdasdf
            </div>
        </main>
    );
}
